package com.research.netspoof;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class NetSpoofModule implements IXposedHookLoadPackage {

    private XSharedPreferences getPrefs() {
        XSharedPreferences p = new XSharedPreferences("com.research.netspoof", Prefs.FILE);
        p.makeWorldReadable();
        return p;
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        XSharedPreferences prefs = getPrefs();

        // Module disabled?
        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) return;

        // Check target package
        String target = prefs.getString(Prefs.KEY_TARGET_PKG, "");
        if (target.isEmpty() || !target.equals(lp.packageName)) return;

        XposedBridge.log("[NetSpoof] Injected → " + lp.packageName);

        // Read fake values (reload for freshness)
        prefs.reload();
        final String fNum    = prefs.getString(Prefs.KEY_NUMBER,     Prefs.DEF_NUMBER);
        final String fImsi   = prefs.getString(Prefs.KEY_IMSI,       Prefs.DEF_IMSI);
        final String fOp     = prefs.getString(Prefs.KEY_OPERATOR,   Prefs.DEF_OPERATOR);
        final String fSimOp  = prefs.getString(Prefs.KEY_SIM_OP,     Prefs.DEF_SIM_OP);
        final String fIccid  = prefs.getString(Prefs.KEY_ICCID,      Prefs.DEF_ICCID);
        final String fCtry   = prefs.getString(Prefs.KEY_COUNTRY,    Prefs.DEF_COUNTRY);
        final String fMcc    = prefs.getString(Prefs.KEY_MCC_MNC,    Prefs.DEF_MCC_MNC);
        final String fAid    = prefs.getString(Prefs.KEY_ANDROID_ID, Prefs.DEF_ANDROID_ID);
        final String fImei   = prefs.getString(Prefs.KEY_IMEI,       Prefs.DEF_IMEI);

        ClassLoader cl = lp.classLoader;

        hookTelephony(cl, fNum, fImsi, fOp, fSimOp, fIccid, fCtry, fMcc, fImei);
        hookWifi(cl);
        hookBuild(cl);
        hookAndroidId(cl, fAid);
    }

    // ═══════════════════════════════════════════════════════════
    //  TELEPHONY
    // ═══════════════════════════════════════════════════════════
    private void hookTelephony(ClassLoader cl,
            String num, String imsi, String op, String simOp,
            String iccid, String country, String mccmnc, String imei) {

        hook(cl, "android.telephony.TelephonyManager", "getLine1Number",         num);
        hook(cl, "android.telephony.TelephonyManager", "getSubscriberId",        imsi);
        hook(cl, "android.telephony.TelephonyManager", "getNetworkOperatorName", op);
        hook(cl, "android.telephony.TelephonyManager", "getSimOperatorName",     simOp);
        hook(cl, "android.telephony.TelephonyManager", "getSimSerialNumber",     iccid);
        hook(cl, "android.telephony.TelephonyManager", "getSimCountryIso",       country);
        hook(cl, "android.telephony.TelephonyManager", "getNetworkCountryIso",   country);
        hook(cl, "android.telephony.TelephonyManager", "getNetworkOperator",     mccmnc);
        hook(cl, "android.telephony.TelephonyManager", "getSimOperator",         mccmnc);
        hook(cl, "android.telephony.TelephonyManager", "getDeviceId",            imei);
        // Network type → LTE
        try {
            XposedHelpers.findAndHookMethod(
                    "android.telephony.TelephonyManager", cl, "getNetworkType",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(13); // NETWORK_TYPE_LTE
                        }
                    });
            XposedHelpers.findAndHookMethod(
                    "android.telephony.TelephonyManager", cl, "getDataNetworkType",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(13);
                        }
                    });
        } catch (Throwable t) { XposedBridge.log("[NetSpoof] net-type hook: " + t.getMessage()); }

        XposedBridge.log("[NetSpoof] Telephony hooks OK");
    }

    // ═══════════════════════════════════════════════════════════
    //  WIFI
    // ═══════════════════════════════════════════════════════════
    private void hookWifi(ClassLoader cl) {
        hook(cl, "android.net.wifi.WifiInfo", "getMacAddress", "02:00:00:00:00:00");
        hook(cl, "android.net.wifi.WifiInfo", "getBSSID",      "02:00:00:00:00:00");
    }

    // ═══════════════════════════════════════════════════════════
    //  BUILD PROPS (root hide)
    // ═══════════════════════════════════════════════════════════
    private void hookBuild(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(
                    "android.os.SystemProperties", cl,
                    "get", String.class, String.class,
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            String key = (String) p.args[0];
                            if ("ro.build.tags".equals(key))  p.setResult("release-keys");
                            if ("ro.debuggable".equals(key))  p.setResult("0");
                        }
                    });
        } catch (Throwable t) { XposedBridge.log("[NetSpoof] build hook: " + t.getMessage()); }
    }

    // ═══════════════════════════════════════════════════════════
    //  ANDROID ID
    // ═══════════════════════════════════════════════════════════
    private void hookAndroidId(ClassLoader cl, final String fakeId) {
        try {
            XposedHelpers.findAndHookMethod(
                    "android.provider.Settings$Secure", cl,
                    "getString",
                    "android.content.ContentResolver", String.class,
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            if ("android_id".equals(p.args[1])) p.setResult(fakeId);
                        }
                    });
        } catch (Throwable t) { XposedBridge.log("[NetSpoof] android_id hook: " + t.getMessage()); }
    }

    // ═══════════════════════════════════════════════════════════
    //  HELPER — hook zero-arg method returning String
    // ═══════════════════════════════════════════════════════════
    private static void hook(ClassLoader cl, String cls, String method, final String val) {
        try {
            XposedHelpers.findAndHookMethod(cls, cl, method, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    p.setResult(val);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("[NetSpoof] skip [" + method + "]: " + t.getMessage());
        }
    }
}
