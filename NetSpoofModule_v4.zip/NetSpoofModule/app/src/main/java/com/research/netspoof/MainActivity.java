package com.research.netspoof;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    // ── UI refs ──────────────────────────────────────────────────
    private SwitchCompat swEnabled;
    private ImageView    ivAppIcon;
    private TextView     tvAppName, tvAppPkg, tvStatus, tvCarrierBadge;
    private EditText     etNumber, etImsi, etOperator, etSimOp,
                         etIccid, etCountry, etMccMnc, etAndroidId, etImei;
    private Button       btnSelectApp, btnSave;
    private View         cardAppEmpty, cardAppSelected;

    private SharedPreferences prefs;
    private String selectedPkg = "", selectedName = "";
    private final Random rng = new Random();

    // ── App selector launcher ─────────────────────────────────────
    private final ActivityResultLauncher<Intent> appPicker =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                selectedPkg  = result.getData().getStringExtra(AppSelectActivity.EXTRA_PKG);
                selectedName = result.getData().getStringExtra(AppSelectActivity.EXTRA_NAME);
                updateAppCard();
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        prefs = getSharedPreferences(Prefs.FILE, Context.MODE_PRIVATE);
        bindViews();
        loadPrefs();
        setupListeners();

        // First launch: auto-detect carrier from whatever number is in the field
        applyCarrierFromNumber(etNumber.getText().toString(), false);
    }

    // ── Bind views ────────────────────────────────────────────────
    private void bindViews() {
        swEnabled       = findViewById(R.id.sw_enabled);
        ivAppIcon       = findViewById(R.id.iv_app_icon);
        tvAppName       = findViewById(R.id.tv_app_name);
        tvAppPkg        = findViewById(R.id.tv_app_pkg);
        tvStatus        = findViewById(R.id.tv_status);
        cardAppEmpty    = findViewById(R.id.card_app_empty);
        cardAppSelected = findViewById(R.id.card_app_selected);
        btnSelectApp    = findViewById(R.id.btn_select_app);
        etNumber        = findViewById(R.id.et_number);
        etImsi          = findViewById(R.id.et_imsi);
        etOperator      = findViewById(R.id.et_operator);
        etSimOp         = findViewById(R.id.et_sim_op);
        etIccid         = findViewById(R.id.et_iccid);
        etCountry       = findViewById(R.id.et_country);
        etMccMnc        = findViewById(R.id.et_mcc_mnc);
        etAndroidId     = findViewById(R.id.et_android_id);
        etImei          = findViewById(R.id.et_imei);
        btnSave         = findViewById(R.id.btn_save);
        // Optional carrier badge (if exists in layout)
        tvCarrierBadge  = findViewById(R.id.tv_carrier_badge);
    }

    // ── Load saved prefs ──────────────────────────────────────────
    private void loadPrefs() {
        swEnabled.setChecked(prefs.getBoolean(Prefs.KEY_ENABLED, true));
        selectedPkg  = prefs.getString(Prefs.KEY_TARGET_PKG,  "");
        selectedName = prefs.getString(Prefs.KEY_TARGET_NAME, "");

        etNumber   .setText(prefs.getString(Prefs.KEY_NUMBER,     Prefs.DEF_NUMBER));
        etImsi     .setText(prefs.getString(Prefs.KEY_IMSI,       Prefs.DEF_IMSI));
        etOperator .setText(prefs.getString(Prefs.KEY_OPERATOR,   Prefs.DEF_OPERATOR));
        etSimOp    .setText(prefs.getString(Prefs.KEY_SIM_OP,     Prefs.DEF_SIM_OP));
        etIccid    .setText(prefs.getString(Prefs.KEY_ICCID,      Prefs.DEF_ICCID));
        etCountry  .setText(prefs.getString(Prefs.KEY_COUNTRY,    Prefs.DEF_COUNTRY));
        etMccMnc   .setText(prefs.getString(Prefs.KEY_MCC_MNC,    Prefs.DEF_MCC_MNC));
        etAndroidId.setText(prefs.getString(Prefs.KEY_ANDROID_ID, Prefs.DEF_ANDROID_ID));
        etImei     .setText(prefs.getString(Prefs.KEY_IMEI,       Prefs.DEF_IMEI));

        updateAppCard();
        updateStatusBadge();
    }

    // ── Listeners ─────────────────────────────────────────────────
    private void setupListeners() {
        swEnabled.setOnCheckedChangeListener((b, c) -> updateStatusBadge());

        View.OnClickListener openPicker = v -> {
            Intent i = new Intent(this, AppSelectActivity.class);
            i.putExtra(AppSelectActivity.EXTRA_SEL, selectedPkg);
            appPicker.launch(i);
        };
        btnSelectApp.setOnClickListener(openPicker);
        cardAppEmpty.setOnClickListener(openPicker);
        View changeBtn = findViewById(R.id.btn_change_app);
        if (changeBtn != null) changeBtn.setOnClickListener(openPicker);

        // ── NUMBER FIELD: live carrier detection ─────────────────
        // As soon as user types/changes the number, all network fields
        // update automatically to match that number's real carrier
        etNumber.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                String num = s.toString().trim();
                // Only auto-detect when number looks reasonably complete
                if (num.length() >= 7) {
                    applyCarrierFromNumber(num, false);
                }
            }
        });

        // ── My Real Values: reads real SIM number + real network ──
        View btnReadReal = findViewById(R.id.btn_read_real);
        if (btnReadReal != null) {
            btnReadReal.setOnClickListener(v -> loadRealSimThenDetect());
        }

        // ── Randomize All: random India number + its carrier ──────
        View btnRandom = findViewById(R.id.btn_randomize);
        if (btnRandom != null) {
            btnRandom.setOnClickListener(v -> {
                String fakeNum = randomPhone();
                etNumber.setText(fakeNum);             // triggers TextWatcher above
                etAndroidId.setText(randomHex(16));
                etImei.setText(randomImei());
                Toast.makeText(this, "🎲 Random identity generated!", Toast.LENGTH_SHORT).show();
            });
        }

        // Per-field randomize — only for non-network fields
        setRandBtn(R.id.btn_rand_android_id, () -> etAndroidId.setText(randomHex(16)));
        setRandBtn(R.id.btn_rand_imei,       () -> etImei.setText(randomImei()));
        // Number field random also re-triggers carrier detection
        setRandBtn(R.id.btn_rand_number, () -> etNumber.setText(randomPhone()));

        // IMSI / ICCID random: regenerate using current MCC+MNC
        setRandBtn(R.id.btn_rand_imsi,  () -> etImsi.setText(genImsi(etMccMnc.getText().toString())));
        setRandBtn(R.id.btn_rand_iccid, () -> etIccid.setText(genIccid(etMccMnc.getText().toString())));

        // Save
        btnSave.setOnClickListener(v -> doSave());
    }

    private void setRandBtn(int id, Runnable r) {
        View v = findViewById(id);
        if (v != null) v.setOnClickListener(b -> r.run());
    }

    // ══════════════════════════════════════════════════════════════
    //  CORE: detect carrier from number → fill all network fields
    // ══════════════════════════════════════════════════════════════
    private void applyCarrierFromNumber(String number, boolean showToast) {
        CarrierLookup.CarrierInfo info = CarrierLookup.detect(number);
        if (info == null) return;

        // Fill all network fields to match this number's carrier
        etOperator.setText(info.operator);
        etSimOp   .setText(info.simOp);
        etCountry .setText(info.country);
        etMccMnc  .setText(info.mccMnc);

        // Generate IMSI: carrier MCC+MNC prefix + unique random MSIN
        etImsi.setText(genImsi(info.mccMnc));

        // Generate ICCID: carrier prefix + random suffix
        etIccid.setText(genIccid(info.mccMnc));

        // Update carrier badge if exists
        if (tvCarrierBadge != null) {
            tvCarrierBadge.setText("📡 " + info.operator);
            tvCarrierBadge.setVisibility(View.VISIBLE);
        }

        if (showToast) {
            Toast.makeText(this,
                "📡 " + info.operator + " detected! Fields updated.",
                Toast.LENGTH_SHORT).show();
        }
    }

    // ── Load real SIM number then detect its carrier ──────────────
    private void loadRealSimThenDetect() {
        try {
            android.telephony.TelephonyManager tm =
                    (android.telephony.TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            if (tm == null) return;

            String realNum = tm.getLine1Number();
            if (realNum != null && !realNum.isEmpty()) {
                etNumber.setText(realNum);
                // TextWatcher will auto-call applyCarrierFromNumber
                Toast.makeText(this,
                    "📱 Real number loaded — carrier auto-detected!",
                    Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
                    "⚠ Number read nahi ho raha — manually enter karo",
                    Toast.LENGTH_SHORT).show();
            }
        } catch (SecurityException e) {
            Toast.makeText(this,
                "⚠ Phone permission chahiye — Settings mein allow karo",
                Toast.LENGTH_SHORT).show();
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  SAVE — everything already filled by carrier detection
    // ══════════════════════════════════════════════════════════════
    private void doSave() {
        if (selectedPkg.isEmpty()) {
            Toast.makeText(this, "⚠ Pehle game select karo!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Force one final carrier sync before saving
        applyCarrierFromNumber(etNumber.getText().toString().trim(), false);

        prefs.edit()
            .putBoolean(Prefs.KEY_ENABLED,    swEnabled.isChecked())
            .putString(Prefs.KEY_TARGET_PKG,  selectedPkg)
            .putString(Prefs.KEY_TARGET_NAME, selectedName)
            .putString(Prefs.KEY_NUMBER,      etNumber.getText().toString().trim())
            .putString(Prefs.KEY_IMSI,        etImsi.getText().toString().trim())
            .putString(Prefs.KEY_OPERATOR,    etOperator.getText().toString().trim())
            .putString(Prefs.KEY_SIM_OP,      etSimOp.getText().toString().trim())
            .putString(Prefs.KEY_ICCID,       etIccid.getText().toString().trim())
            .putString(Prefs.KEY_COUNTRY,     etCountry.getText().toString().trim())
            .putString(Prefs.KEY_MCC_MNC,     etMccMnc.getText().toString().trim())
            .putString(Prefs.KEY_ANDROID_ID,  etAndroidId.getText().toString().trim())
            .putString(Prefs.KEY_IMEI,        etImei.getText().toString().trim())
            .apply();

        String carrier = etOperator.getText().toString().trim();
        btnSave.setText("✓ Saved!");
        btnSave.postDelayed(() -> btnSave.setText("💾 Save & Apply"), 1800);
        Toast.makeText(this,
            "✅ " + carrier + " network spoofed! Game restart karo.",
            Toast.LENGTH_LONG).show();
        updateStatusBadge();
    }

    // ── Generate IMSI from MCC+MNC ────────────────────────────────
    private String genImsi(String mccMnc) {
        String prefix = (mccMnc != null && mccMnc.length() >= 5) ? mccMnc : "40410";
        // 15-digit IMSI = MCC(3)+MNC(2)+MSIN(10)
        int msinLen = 15 - prefix.length();
        StringBuilder sb = new StringBuilder(prefix);
        for (int i = 0; i < msinLen; i++) sb.append(rng.nextInt(10));
        return sb.toString();
    }

    // ── Generate ICCID from carrier info ─────────────────────────
    private String genIccid(String mccMnc) {
        // ICCID format: 89 + country_code + carrier_code + serial (20 digits total)
        // Use MCC as country indicator
        String mcc = (mccMnc != null && mccMnc.length() >= 3) ? mccMnc.substring(0, 3) : "404";
        // Map MCC to ITU country code for ICCID
        String ituCode;
        switch (mcc) {
            case "404": case "405": ituCode = "91";  break; // India
            case "310": case "311": ituCode = "01";  break; // USA
            case "234": case "235": ituCode = "44";  break; // UK
            case "424":             ituCode = "971"; break; // UAE
            case "420":             ituCode = "966"; break; // Saudi
            case "410":             ituCode = "92";  break; // Pakistan
            case "470":             ituCode = "880"; break; // Bangladesh
            case "505":             ituCode = "61";  break; // Australia
            default:                ituCode = "91";  break;
        }
        String base = "89" + ituCode;
        int remaining = 20 - base.length();
        StringBuilder sb = new StringBuilder(base);
        for (int i = 0; i < remaining; i++) sb.append(rng.nextInt(10));
        return sb.toString();
    }

    // ── UI helpers ────────────────────────────────────────────────
    private void updateAppCard() {
        if (selectedPkg.isEmpty()) {
            cardAppEmpty.setVisibility(View.VISIBLE);
            cardAppSelected.setVisibility(View.GONE);
        } else {
            cardAppEmpty.setVisibility(View.GONE);
            cardAppSelected.setVisibility(View.VISIBLE);
            tvAppName.setText(selectedName.isEmpty() ? selectedPkg : selectedName);
            tvAppPkg.setText(selectedPkg);
            try {
                Drawable icon = getPackageManager().getApplicationIcon(selectedPkg);
                ivAppIcon.setImageDrawable(icon);
            } catch (PackageManager.NameNotFoundException e) {
                ivAppIcon.setImageResource(android.R.drawable.sym_def_app_icon);
            }
        }
    }

    private void updateStatusBadge() {
        boolean on = swEnabled.isChecked() && !selectedPkg.isEmpty();
        tvStatus.setText(on ? "● ACTIVE" : "○ INACTIVE");
        tvStatus.setTextColor(getResources().getColor(
                on ? R.color.green_active : R.color.text_secondary, null));
    }

    // ── Random generators ─────────────────────────────────────────
    private final Random rngg = new Random();

    private String randomPhone() {
        // Random India mobile: +91 + 7/8/9 + 9 digits
        int prefix = new int[]{7, 8, 9}[rng.nextInt(3)];
        return "+91" + prefix + String.format("%09d", rng.nextInt(1_000_000_000));
    }

    private String randomHex(int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) sb.append("0123456789abcdef".charAt(rng.nextInt(16)));
        return sb.toString();
    }

    private String randomImei() {
        StringBuilder sb = new StringBuilder("35");
        for (int i = 0; i < 13; i++) sb.append(rng.nextInt(10));
        return sb.toString();
    }
}
